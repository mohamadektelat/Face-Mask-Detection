# Face-Mask-Detection-Project
Graduation project: Face mask detection based AI 
by: 
Abedallah Joulany &
Mohamad Ektelat
Moderator:
Sagiv Tuvia
